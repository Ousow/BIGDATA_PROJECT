import pyarrow.parquet as pq
import pyarrow as pa
import pandas as pd
import os

input_path = "data/gold/GOLD_FEATURES.parquet"
output_path = "data/gold/GOLD_FEATURES_LIGHT.parquet"

# Colonnes utiles
cols = [
    "severity", "DATE", "year", "month", "day_acc", "hour",
    "route_type", "urban_rural",
    "vehicle_type", "collision_type",
    "state_acc", "county", "city",
    "TMAX", "TMIN", "PRCP", "SNOW", "SNWD"
]

print("Ouverture du fichier parquet...")
parquet_file = pq.ParquetFile(input_path)

# Writer vide au début
writer = None

# Parcourt chaque row group
for i in range(parquet_file.num_row_groups):
    print(f"Lecture row group {i+1}/{parquet_file.num_row_groups}...")

    # Lecture du fragment
    table = parquet_file.read_row_group(i, columns=[c for c in cols if c in parquet_file.schema.names])

    # Première itération → créer fichier
    if writer is None:
        writer = pq.ParquetWriter(output_path, table.schema)

    writer.write_table(table)

# Finalisation
if writer:
    writer.close()

print("\nFichier allégé créé : ", output_path)
